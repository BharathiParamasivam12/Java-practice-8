package com.java.practice.practicecode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticecodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
